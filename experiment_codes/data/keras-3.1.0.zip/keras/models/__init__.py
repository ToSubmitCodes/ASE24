from keras.models.functional import Functional
from keras.models.model import Model
from keras.models.sequential import Sequential
