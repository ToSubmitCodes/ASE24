"""Small NumPy datasets for debugging/testing."""

from keras.datasets import boston_housing
from keras.datasets import california_housing
from keras.datasets import cifar10
from keras.datasets import cifar100
from keras.datasets import fashion_mnist
from keras.datasets import imdb
from keras.datasets import mnist
from keras.datasets import reuters
